# MyFaceGuard LinkedIn Content Agent

An agentic AI tool that researches, drafts, and prepares weekly LinkedIn posts for MyFaceGuard — focused on facial recognition, biometric privacy, GDPR enforcement, and the EU AI Act.

Built on the **Agentic AI Architecture & Context Engineering** framework designed in Miro.

---

## Architecture

| Layer | Implementation |
|---|---|
| Business Objective | Weekly LinkedIn post on EU biometric/privacy news |
| Agent Role | Research & content strategist (human-in-the-loop) |
| Tasks | Web search → filter → draft → approve |
| Context | EU/GDPR/AI Act focus, MyFaceGuard brand voice |
| Memory | Short-term (session) + persistent (brand rules) |
| Tooling | Claude API with web search + content drafting |
| Human Interaction | 5-step approval workflow, never auto-publishes |
| Reasoning | Reflect → Evaluate → Refine → Execute loop |

---

## How It Works

```
1. Run Weekly Research   →  Agent searches EU biometric/privacy news (live web search)
2. Select Topic          →  Human picks from agent's scored shortlist
3. Draft Post            →  Agent writes 4-sentence post + visual concept
4. Review & Edit         →  Human reviews, edits in-browser
5. Approve & Copy        →  Human copies final post, publishes manually on LinkedIn
```

The agent **never publishes automatically**. Final approval always stays with the human.

---

## Project Structure

```
linkedinpost/
├── public/
│   └── index.html          # Main agent UI (single-file app)
├── src/
│   └── agent.js            # Agent logic (extracted, importable)
├── docs/
│   └── architecture.md     # Full agent architecture reference
├── .env.example            # Environment variables template
├── .gitignore
└── README.md
```

---

## Setup

### Option A — Open directly in browser
Just open `public/index.html` in any modern browser. The app calls the Anthropic API directly from the browser.

### Option B — Serve locally
```bash
npx serve public
# or
python3 -m http.server 8080 --directory public
```
Then open `http://localhost:8080`

### Option C — Deploy to GitHub Pages
1. Go to your repo → Settings → Pages
2. Set source to `main` branch, `/public` folder
3. Your agent will be live at `https://evaluksa.github.io/linkedinpost/`

---

## Configuration

Copy `.env.example` to `.env` and add your Anthropic API key:

```bash
ANTHROPIC_API_KEY=sk-ant-...
```

> **Note:** For the current browser-based version, the API key is handled by the Anthropic proxy. For a self-hosted version, you would inject it via a backend or environment variable.

---

## Agent Reasoning Loop

Based on the **Reflect → Evaluate → Refine → Execute** model:

- **Reflect** — Is this topic relevant for MyFaceGuard followers in Europe? Does it connect to consent, privacy, or biometric risk?
- **Evaluate** — Is the story recent, factual, and supported by trusted sources? Is it useful, not just sensational?
- **Refine** — Make the angle simple, practical, and easy to understand. Connect it to MyFaceGuard's mission.
- **Execute** — Write one final LinkedIn post in 4 short sentences. Add a simple CTA. Suggest one minimal design visual concept.

---

## Tech Stack

- **Frontend:** Vanilla HTML/CSS/JS (zero dependencies, no build step)
- **AI:** Anthropic Claude API (`claude-sonnet-4-20250514`) with web search tool
- **Deployment:** GitHub Pages compatible

---

## Customisation

To adapt this agent for a different brand or topic:

1. Edit the `systemPrompt` in `src/agent.js`
2. Update the persistent memory values in the sidebar (brand voice, audience, themes)
3. Change the search keywords in `runSearch()`

---

## License

MIT
