# Agent Architecture Reference

Based on: **Agentic AI Architecture & Context Engineering** (Miro board)

---

## 1. Business Objective

**Problem:** MyFaceGuard needs one high-quality LinkedIn post per week on the most relevant news about facial recognition, biometric privacy, fines, and image use — especially in Europe.

**Expected outcomes:**
- 1 approved LinkedIn post per week
- Relevant, accurate, and brand-aligned content
- Reduced manual research time

**Success metrics:** Time saved, accuracy, automation level

---

## 2. Agent Role Definition

- **Role:** Research and content strategist
- **Autonomy level:** Suggests and drafts — never publishes
- **Human-in-the-Loop checkpoints:**
  - After topic shortlist (human selects topic)
  - After draft generation (human reviews, edits, approves)

---

## 3. Tasks & Capabilities

| Task | Description |
|---|---|
| Track stories | Search trusted EU/global sources weekly |
| Filter topics | Score for relevance to MyFaceGuard's EU audience |
| Summarise | Explain each topic in plain English |
| Fact-check signal | Flag stories with legal or factual uncertainty |
| Draft post | Write 4-sentence LinkedIn post with hook + CTA |
| Visual concept | Suggest one minimal design direction |
| Tone enforcement | Keep output clear, useful, professional |

---

## 4. Context Engineering

**Primary context sources:**
- Official EU sources (EU Commission, CNIL, regulators)
- Trusted news (Reuters, BBC, Euractiv, Politico Europe)
- MyFaceGuard brand guidelines (voice, format, audience)

**Key context rules:**
- EU/GDPR/AI Act focus first
- Include brand voice: clear, trustworthy, professional
- Post format: 4 short sentences + CTA
- Visual: minimal design, two-color

---

## 5. Memory Design

### Short-term (session)
- Current weekly topic shortlist
- Selected topic and angle
- Draft caption and image idea
- Key source links

### Persistent
- MyFaceGuard brand voice
- Audience profile (European business & tech professionals)
- Preferred post format (4 sentences)
- Strong recurring themes: GDPR, AI Act, Biometrics, Photo Consent
- Approved minimal visual style

---

## 6. Tooling & Integrations

| Tool | Purpose |
|---|---|
| Web search | Find recent news and official updates |
| Source checker | Cross-reference facts across sources |
| Content drafting | Write post in brand voice |
| Visual prompt generator | Suggest image concept |
| Content archive | Store approved posts and results |

---

## 7. Human Interaction Model

**Workflow:**
1. Agent sends weekly topic shortlist
2. Human selects one topic
3. Agent prepares final post draft
4. Human reviews tone, accuracy, and legal sensitivity
5. Human improves draft if needed (agent revises)
6. Human gives final approval
7. Human publishes manually on LinkedIn

**Interaction types:**
- Review: feedback on draft
- Approval gates: topic selection + post approval
- Prompt steering: refinement instructions

---

## 8. Reasoning & Planning Loop

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│   REFLECT              →        EVALUATE            │
│                                                     │
│   Is this topic           Is the story recent,      │
│   relevant for            factual, and supported    │
│   MyFaceGuard             by trusted sources?       │
│   followers in            Is it useful, not just    │
│   Europe?                 sensational?              │
│   Does it connect                                   │
│   to consent,                                       │
│   privacy, photo                                    │
│   use, or biometric                                 │
│   risk?                                             │
│                                                     │
│   REFINE               →        EXECUTE             │
│                                                     │
│   Make the angle          Write one final           │
│   simple, practical,      LinkedIn post in          │
│   and easy to             4 short sentences.        │
│   understand.             Add a simple CTA.         │
│   Connect to              Suggest one minimal       │
│   MyFaceGuard's           design visual             │
│   mission and             concept.                  │
│   audience value.                                   │
│                                                     │
└─────────────────────────────────────────────────────┘
```
