/**
 * MyFaceGuard LinkedIn Content Agent
 * Core agent logic — extracted for reuse / testing
 *
 * Architecture: Reflect → Evaluate → Refine → Execute
 */

const ANTHROPIC_API = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-20250514";

// ─── Persistent Memory (Brand Rules) ───────────────────────────────────────

export const BRAND_MEMORY = {
  voice: "Clear, trustworthy, EU-focused, no jargon",
  audience: "European business and tech professionals",
  postFormat: "4 short sentences: hook → insight → relevance → CTA",
  visualStyle: "Minimal design, two-color, white background",
  recurringThemes: ["GDPR", "Biometrics", "EU AI Act", "Facial Recognition", "Photo Consent", "Data Privacy"],
  language: "English",
  publishRule: "Human always approves before publishing. Agent never auto-publishes.",
};

// ─── System Prompt ──────────────────────────────────────────────────────────

export const SYSTEM_PROMPT = `
You are a research and content strategist for MyFaceGuard, a company focused on facial recognition, biometric privacy, and responsible photo use in Europe.

Your role:
- Find important stories and explain them in simple business language
- Connect stories to privacy, trust, and responsible photo use
- Suggest strong post angles, but never publish automatically
- Always keep a human approval step before the final post and visual

Brand voice: ${BRAND_MEMORY.voice}
Audience: ${BRAND_MEMORY.audience}
Post format: ${BRAND_MEMORY.postFormat}
Key themes: ${BRAND_MEMORY.recurringThemes.join(", ")}
`.trim();

// ─── Phase 1: Research ──────────────────────────────────────────────────────

/**
 * Search for this week's most relevant EU biometric/privacy news.
 * Returns array of scored topic objects.
 */
export async function runWeeklyResearch() {
  const prompt = `
Search for the 4 most recent and relevant news stories from the last 7 days about:
facial recognition, biometric privacy, GDPR enforcement fines, EU AI Act developments,
photo consent laws, or related topics in Europe.

For each story, respond in this EXACT JSON format (return only the JSON array, no other text):
[
  {
    "title": "Story title",
    "source": "Source name",
    "date": "Approximate date",
    "summary": "2-sentence summary in simple business language",
    "relevance": 85,
    "angle": "Why this matters for MyFaceGuard and European business audience",
    "flags": ["GDPR", "Biometrics"],
    "legal_risk": false
  }
]

Score relevance 0-100 based on: EU focus, facial recognition/biometrics connection,
audience value, recency. Flag legal_risk true if there's factual uncertainty.
`;

  const raw = await callClaude(prompt, "Return ONLY valid JSON array. No markdown, no explanation.");
  return parseJsonResponse(raw, []);
}

// ─── Phase 2: Reflect & Evaluate ────────────────────────────────────────────

/**
 * Agent reasoning: score a topic for audience fit and factual confidence.
 * Returns { relevant: bool, reasoning: string, confidence: number }
 */
export async function reflectOnTopic(topic) {
  const prompt = `
Evaluate this news story for MyFaceGuard's LinkedIn audience in Europe:

TITLE: ${topic.title}
SUMMARY: ${topic.summary}

Answer these questions and return ONLY JSON:
{
  "relevant": true/false,
  "connects_to_consent_or_privacy": true/false,
  "is_recent_and_factual": true/false,
  "useful_not_sensational": true/false,
  "confidence": 0-100,
  "reasoning": "1 sentence explaining your decision"
}
`;
  const raw = await callClaude(prompt, "Return ONLY valid JSON. No markdown.");
  return parseJsonResponse(raw, { relevant: true, confidence: 80, reasoning: "Topic is relevant to EU biometrics." });
}

// ─── Phase 3: Refine & Execute ──────────────────────────────────────────────

/**
 * Draft a LinkedIn post for the selected topic.
 * Returns { body, visual_concept, risk_flags }
 */
export async function draftLinkedInPost(topic, extraInstruction = "") {
  const prompt = `
Write a LinkedIn post for MyFaceGuard about this story:

TOPIC: ${topic.title}
SUMMARY: ${topic.summary}
ANGLE: ${topic.angle}
FLAGS: ${(topic.flags || []).join(", ")}
${extraInstruction ? `ADDITIONAL INSTRUCTION: ${extraInstruction}` : ""}

Requirements:
- Exactly 4 short sentences
- Start with a strong hook (surprising fact, question, or statement)
- Connect the topic to privacy, consent, or biometric risk in simple language
- End with a clear CTA relevant to MyFaceGuard's mission
- Tone: ${BRAND_MEMORY.voice}
- Audience: ${BRAND_MEMORY.audience}
- Do NOT use jargon

Then suggest ONE minimal visual concept (1 sentence describing a simple, clean graphic idea).

Respond in this exact JSON format (no markdown, just JSON):
{
  "hook": "Opening sentence",
  "body": "Full 4-sentence post text including hook",
  "cta": "CTA text",
  "visual_concept": "Visual idea description",
  "risk_flags": []
}
`;
  const raw = await callClaude(prompt, SYSTEM_PROMPT);
  return parseJsonResponse(raw, { body: raw.substring(0, 600), visual_concept: "Clean shield icon, minimal two-color design.", risk_flags: [] });
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function callClaude(userPrompt, systemPrompt) {
  const response = await fetch(ANTHROPIC_API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1000,
      system: systemPrompt || SYSTEM_PROMPT,
      messages: [{ role: "user", content: userPrompt }],
      tools: [{ type: "web_search_20250305", name: "web_search" }],
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Anthropic API error ${response.status}: ${err}`);
  }

  const data = await response.json();
  return data.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");
}

function parseJsonResponse(raw, fallback) {
  try {
    const match = raw.match(/[\[{][\s\S]*[\]}]/);
    if (match) return JSON.parse(match[0]);
  } catch (e) {
    console.warn("JSON parse failed, using fallback", e);
  }
  return fallback;
}
